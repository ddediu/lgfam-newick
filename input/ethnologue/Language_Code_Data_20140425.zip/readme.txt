
Ethnologue 17th edition, SIL International, 2014.


Three-letter codes for identifying languages:
Download tables

    See http://www.ethnologue.com/codes/ for complete documentation on
    what is included in this download package and on how to use it.


Terms of Use for Language Code Download Tables

In the interest of fostering the use of ISO 639-3 for the uniform identification of all the world's languages in information systems, SIL International releases certain information from the Ethnologue database for use in the development of information systems, specifically, information that describes language identifiers in terms of alternate names and countries where spoken. You are welcome to download the information as provided and incorporate the supplied tables into your own database application. You are authorized to include the information in a product that you make available to the public (even on a commercial basis), provided that you:

 - cite SIL International and this web site (www.ethnologue.com) as the source of the information,

 - do not modify or extend the codes other than those set aside for local use (i.e. qaa to qtz), 

 - do not redistribute the code tables for download, and

 - use only the data in the tables and no other data posted on this site. Other information on this site should be accessed by supplying a link like the following (where abc is an ISO 639-3 code):

      http://www.ethnologue.com/language/abc

SIL International periodically updates the supplied information, and intends this site to be the sole distribution source in order to ensure uniformity of versions. You are not authorized to redistribute the code tables for download, whether in the exact form they were obtained from this site or in a modified form you have developed, without the written consent of SIL International. To request permission,  email the Request for Permission to Publish SIL Copyright Materials form (http://www.sil.org/acpub/Copyright_Permissions_Form.doc) to AdministratorCopyrightPermissions_Intl@sil.org.
